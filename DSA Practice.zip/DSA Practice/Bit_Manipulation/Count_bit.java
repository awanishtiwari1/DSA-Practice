import java.util.Scanner;
// A program showing number of one bits in an binary representation of any number
public class Count_bit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int count = 0;
        while(a!=0)
        {
            a = a & a-1;
            count+=1 ;
        }
        System.out.println("No of one bits in given no is :" + count);
    }
}
