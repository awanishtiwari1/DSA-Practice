public class Stack_using_LinkedList {
    Node head;
    private class Node{
        int data;
        Node next;
        Node(int data)
        {
            this.data = data;
        }
    }

    public void push(Stack_using_LinkedList list , int data)
    {
        Node toAdd = new Node(data);
        toAdd.next = head;
        head  = toAdd;
    }
    public void show_Stack(Stack_using_LinkedList list)
    {
        if(list.head==null)
        {
            System.out.println("No any elements in the lsit");
        }
        //Node temp = list.head;
        while(list.head!=null)
        {
            System.out.print(list.head.data+" ");
            list.head = list.head.next;
        }

    }
    public static void main(String[] args) {
       Stack_using_LinkedList s = new Stack_using_LinkedList();

        s.push(s,1);
        s.push(s,2);
        s.push(s,3);
        s.push(s,4);
        s.push(s,5);
            s.show_Stack(s);
    }
}
