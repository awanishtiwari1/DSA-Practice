package Bit_Manipulation;

import Arrays.parent;

import javax.crypto.spec.PSource;

public class child extends parent {
    public static void main(String[] args) {

    }
}
