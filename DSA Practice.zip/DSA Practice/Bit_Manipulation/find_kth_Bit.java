package Bit_Manipulation;

public class find_kth_Bit {
    static int  find_kth_bit(int n , int k)
    {
        //creating a mask
        int mask = 1<<(k-1);

        int res = (n & mask) >> (k-1);
        if(res == 1)
        {
            return 1;
        }
        return 0;


    }


    public static void main(String[] args) {
        int n = 5;
        int k = 3;
        System.out.println(find_kth_bit(n,k));
    }
}
