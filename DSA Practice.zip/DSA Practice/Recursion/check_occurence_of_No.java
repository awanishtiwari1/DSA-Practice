package Recursion;

public class check_occurence_of_No {
    static boolean check_no(int a[] , int n , int start)
    {
        if(start>a.length - 1)
        {
            return false;
        }
        if(a[start] == n)
        {
            return true;
        }
        return check_no(a,n , start+1);

    }
    public static void main(String[] args) {
        int a[] = {1,2,3,4,5};
        System.out.println("No 4 is found " + check_no(a,4, 0));
    }
}
