public class L_List {
    Node head;
    static class Node
    {
        int data;
        Node next;
        Node(int d) {
            data = d;
            next = null;

        }
    }
    public static L_List insert(L_List list , int data )
    {
       Node new_node = new Node(data);
       new_node.next = null;
       if(list.head == null)
       {
           list.head = new_node;
       }
        else
       {
           Node last = list.head;
           while(last.next!=null)
           {
               last = last.next;
           }
           last.next = new_node;
       }
        return list;
    }
    public static L_List insert_at_pos(L_List list , int data , int pos )
    {
        Node new_node = new Node(data);
        if(pos==0)
        {
            list.head = new_node;
            return list;

        }
        else
        {
            Node prev = list.head;
            for(int i = 1 ; i< pos ; i++)
            {
                prev = prev.next;
            }
            new_node.next = prev.next;
            prev.next = new_node;
        }
        return list;
    }
    public static void print(L_List list)
    {
        Node curnode = list.head;
        while (curnode!=null)
        {
            System.out.println(curnode.data);
            curnode = curnode.next;
        }


    }
    public static void delete_at_pos(L_List list , int position)
    {
        Node prev = list.head;
        for(int i = 1 ; i<position ; i++)
        {
            prev = prev.next;
        }
        prev.next = prev.next.next;


    }

    public static void main(String[] args) {
        L_List l = new L_List();
        l = insert(l,1);
        l = insert(l,2);
        l = insert(l,3);
        l = insert(l,4);
        l = insert_at_pos(l,6,2);
        System.out.println("Linked list before deletion");
        print(l);
        System.out.println("Linked list After deletion");
        delete_at_pos(l,2);
        print(l);
    }
}
