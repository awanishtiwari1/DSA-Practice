import java.util.Scanner;

public class Array_Spiral {
    public static void main(String[] args) {
        System.out.println("Enter size of matrix");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int a[][] = new int[n][n];
        System.out.println("Enter elements in arrray");
        for(int i = 0 ; i <a.length ; i++)
        {
            for(int j = 0 ; j<a.length ; j++)
            {
                a[i][j] = sc.nextInt();
            }

        }

        System.out.println("Elements entered by you is ");
        for(int i = 0 ; i<a.length ; i++)
        {
            for(int j =0 ; j<a.length;j++)
            {
                System.out.print(a[i][j]);
            }
        }
    }
}
