package String2;
//Recursion program for Printing fibonacci series
public class recursion {

//    static int printFib(int n )
//    {
//        if(n <= 0 || n == 1)
//        {
//            return n;
//        }
//       return printFib(n-1) + printFib(n-2);
//    }
static int fastExponent(int n )
{
    if(n == 0)
    {
        return 1;
    }
   int answer =  fastExponent(n/2);
    if(answer % 2 == 0)
    {
        return answer * answer;
    }
    else
    {
        return 2*answer*answer;
    }
}


    public static void main(String[] args) {
        System.out.println(fastExponent(3));
    }
}
