package Trees;

import java.util.Scanner;

public class height_of_Binary_Trees {
    static int size_Of_BinaryTree(Node root)
    {
        if(root == null)
            return 0;

        return (size_Of_BinaryTree(root.left) + size_Of_BinaryTree(root.right) + 1);

    }
    static Node createtree()
    {
        Scanner sc = new Scanner(System.in);
        Node root  = null;
        System.out.println("Enter data");
        int data = sc.nextInt();
        if(data == -1)
        {
            return null;
        }
        root = new Node(data);
        System.out.println("Enter left for " + data);
        root.left = createtree();
        System.out.println("Enter right for" + data);
        root.right = createtree();

        return root;

    }


    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
        Node root  = createtree();
        System.out.println(size_Of_BinaryTree(root));


    }
}

class Node1{
    int data;
    Node left , right;
    public Node1(int data)
    {
        this.data = data;
    }


}
