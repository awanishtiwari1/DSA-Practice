public class Pallindrome_Linked_List {
    Node head;
    static class Node{
        int data;
        Node next;

        Node(int data)
        {
            this.data = data;
            next = null;
        }
    }
    public static Pallindrome_Linked_List insert(Pallindrome_Linked_List list,int data)
    {
        Node toAdd = new Node(data);
        toAdd.next =  null;
        if(list.head== null)
        {
            list.head = toAdd;
            return list;
        }
        Node temp = list.head;
        while(temp.next!=null)
        {
            temp = temp.next;
        }
        temp.next = toAdd;
        return list;
    }
    public static boolean check_pallindrome(Pallindrome_Linked_List list)
    {
        if(list.head == null)
        {
            return true;
        }
        Node mid = middle(list);
        Node last = reverse(mid.next);
        Node curr = list.head;
        while (curr!=null)
        {
            if(curr.data != last.data)
            {
                return false;
            }
            curr = curr.next;
            last = last.next;
        }
        return true;
    }

    private static Node reverse(Node next) {
        Node cur = next;
        Node prev = null;
        while(cur!=null)
        {
            Node temp = cur.next;
            cur.next = prev;
            prev = cur;
            cur = temp;
        }
        return prev;
    }

    static Node middle(Pallindrome_Linked_List l)
    {
        Node slow = l.head;
        Node fast = l.head;
        while (fast.next!=null && fast==null)
        {
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
    }
    public static void show_list(Pallindrome_Linked_List list)
    {
        Node curr = list.head;
        while (curr!=null)
        {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
    public static void main(String[] args) {
        Pallindrome_Linked_List list = new Pallindrome_Linked_List();
       insert( list,1);
        insert( list,2);
        insert( list,3);
        insert( list,2);
        insert( list,1);
        //insert( list,6);
        show_list(list);
        System.out.println();
        if(check_pallindrome(list)==true)
        {
            System.out.println("Pallindrome linked list ");
        }
        else
        {
            System.out.println("Linked list is not pallindrome");
        }

    }
}
