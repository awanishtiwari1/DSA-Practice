package Arrays;

public class N_By_Two_Problem {
   static int nByTwo(int a[])
   {
       int n = a.length ;
       n = n/2;
       for(int i =0 ; i<a.length ;i++)
       {
           int count  = 0;
           for(int j = 0 ; j < a.length ;j++)
           {
               if(a[i] == a[j])
               {
                   count+= 1;
                   if(count>n)
                   {
                       System.out.println("No is repeated " + count + " no of times ");
                       return a[i];

                   }
               }
           }
       }
       System.out.println("Am sorry there is no any number whose count is greater that n/2");
       return -1;
   }


    public static void main(String[] args) {
        int a[] = {20, 30, 10, 10, 5, 4, 20, 1, 2};
        int r = nByTwo(a);
        System.out.println(r);
    }
}
