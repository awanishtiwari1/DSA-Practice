//Program to find non repeating element in an array where
//every element repeats twice
public class one_nonrep_element {
    static int check_rep(int arr[])
    {
        int res = 0 ;
        for(int i = 0 ; i< arr.length ; i++)
        {
            res = res ^ arr[i];
        }

        return  res;


    }

    public static void main(String[] args) {

        int a[] = {1,3,1,4,3};

        System.out.println(check_rep(a));

    }
}
