package Arrays;

public class parent {
    protected int a = 10;
    public static void main(String[] args) {


    }
}
