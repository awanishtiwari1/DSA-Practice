import java.util.Scanner;

public class binarySea_recursion {
    int binarysearch(int a[] , int key , int low , int high)
    {
        if(low>high)return -1;
        int mid  = (low+high)/2;

        if(a[mid] == key )
        {
            return a[mid];
        }
        if(key>a[mid])
        {
            return binarysearch(a,key,mid+1,high);

        }
        return binarysearch(a,key,low,mid-1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
       binarySea_recursion bs = new binarySea_recursion();
        System.out.println("Enter no of elements ");
        int n = sc.nextInt();
        int a[] = new int[n];
        System.out.println("Enter elements in the list");
        for(int i = 0 ; i< n ; i++)
        {
            a[i] = sc.nextInt();
        }
        int l = 0;
        int h = a.length-1;
        System.out.println("Enter seraching element");
        int k = sc.nextInt();
        if(bs.binarysearch(a,k,l,h) == k)
        {
            System.out.println("Element found");
        }
        else
            System.out.println("Element not found ");

    }
}
