package String2;

import java.util.Scanner;

public class String_intro {
    public static void main(String[] args) {
//        //First way to declare the string
//        String s;
//        s = "Awanish";
//        System.out.println(s);
//    //Another way
//        String s1 = new String("Awanish");
//        System.out.println(s1);
        //String Arrays creation

        String names[] = new String[3];
        //Array of string of length 3
        //Inserting the values in the String array
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter values String");
//        for(int i = 0 ; i< names.length; i++)
//        {
//            names[i] = sc.nextLine();
//        }
//        System.out.println("Value enetered by you ");
//        for(int i = 0 ; i< names.length; i++)
//        {
//            System.out.println(names[i]);
//        }
    }
}
