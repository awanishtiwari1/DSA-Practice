import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Pallindrome_String {
    static boolean is_pallindrome(String s)
    {
        String t = s;
        int l = s.length();
        char[] s1 = new char[l];
        for(int i =0 ; i<s.length();i++)
        {
            s1[i] =  s.charAt(i);
        }
        int i = 0;
        int n = s1.length-1;
        while (i<n/2)
        {
           char temp = s1[i];
           s1[i] = s1[n];
           s1[n] = temp;
            i++;
            n--;
        }
        s1.toString();
        if(t.equalsIgnoreCase(String.valueOf(s1)))
        {
            return true;
        }

    return false;
    }
    public static void main(String[] args) {
        InputStreamReader in = new InputStreamReader(System.in);

        BufferedReader br = new BufferedReader(in);

        System.out.println("Enter a string ");
        try {
            String input = br.readLine();
            if(is_pallindrome(input))
            {
                System.out.println("String is pallindrome");
            }
            else
            {
                System.out.println("String is not pallindrome");
            }


        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
