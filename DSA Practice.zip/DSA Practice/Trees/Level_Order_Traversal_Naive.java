//import Trees.Node;


import java.util.Scanner;


public class Level_Order_Traversal_Naive {

    static int height_of_Tree(Node root)
    {
        if(root == null) return 0;

        return (height_of_Tree(root.left) + (height_of_Tree(root.right)) + 1);

    }

//We have created a function which prints the given level of the tree
    //print current level of the tree
    static void print_Current_Level(Node root, int level)
    {
        if(root == null) return;

        if(level == 1)
        {
            System.out.print(root.data + " ");
        }
        else if(level>1)
        {
            print_Current_Level(root.left , level -1 );
            print_Current_Level(root.right , level - 1);
        }

    }


    static Node createtree()
   {
       Scanner sc = new Scanner(System.in);
      Node root  = null;
       System.out.println("Enter data");
       int data = sc.nextInt();
       if(data == -1)
       {
           return null;
       }
       root = new Node(data);
       System.out.println("Enter left for " + data);
       root.left = createtree();
       System.out.println("Enter right for" + data);
       root.right = createtree();

       return root;



   }

    public static void main(String[] args) {
        System.out.println("Enter the nodes of the tree");
        Node root = createtree();
        int height = height_of_Tree(root);
        System.out.println("Level order traversal of the tree");
        for(int i =1 ; i<= height ; i++)
        {
            print_Current_Level(root , i);
        }


    }
}