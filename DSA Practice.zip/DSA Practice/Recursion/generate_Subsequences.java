package Recursion;

import java.util.ArrayList;
import java.util.List;

public class generate_Subsequences {
    static List<String> al = new ArrayList<>();
    static void print_SubSequences(String s , String ans) {
       if( s.length() == 0)
       {
            al.add(ans);
           System.out.println(ans);
           return;
       }
       print_SubSequences(s.substring(1) , ans);
       print_SubSequences(s.substring(1), ans+s.charAt(0));

    }
    static void print(String s , String ans , int start , int end)
    {
        if(start == end)
        {
            System.out.println(ans);
            return;
        }


    }
    public static void main(String[] args) {
        String s = "ABC";
        String curr = "";
        int start = 0;
        int end = s.length() -1;
        print(s,curr , start , end);
    }
}
