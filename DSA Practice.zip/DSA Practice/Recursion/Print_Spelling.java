package Recursion;


// A recursive program to print spelling of the given number
public class Print_Spelling {

    static void print_spell(String a[] , int n)
    {
        if(n == 0)
        {
            return;
        }
        print_spell(a,n/10);
        int p = n % 10;
        System.out.println(a[p]);
    }

    public static void main(String[] args) {
        String a[] = {"zero", "One" , "Two" , "Three" , "four" , "five" , "Six" , "Seven" ,"Eight" , "Nine"};
        print_spell(a,2200);
    }
}
