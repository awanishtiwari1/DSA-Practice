package Arrays;

public class merge_two_Sorted {
    static void merge(int a[] , int b[])
    {
        for(int i = 0 ; i < b.length - 1 ; i++)
        {
            int temp = b[i];
            int j = a.length - 1;
            int t = j;
            while (j>=0 && a[j] >=temp)
            {
                a[j+1] = a[j];
                j--;
                t++;
            }
        a[j+1] = temp;

        }
        System.out.println("Array after merging");
        for(int i = 0 ; i < a.length -1 ; i++)
        {
            System.out.print(a[i] + " ");
        }

    }

    public static void main(String[] args) {
        int a[] = { 1 , 2 , 3, 0 , 0 , 0};
        int b[] = { 2,5,6};
            merge(a,b);
    }
}
