package Recursion;
//Task is t find out no ways in which a person can be reach upto stairs by taking 1 , 2 or 3 steps at at time
public class No_Of_Jumps {
    static int number_of_jumps(int n)
    {
        if(n<0)
        {
            return 0;
        }
        if(n == 0)
        {
            return 1;
        }
        return number_of_jumps(n-1) + number_of_jumps(n-2) + number_of_jumps(n-3);
    }


    public static void main(String[] args) {
        int r = number_of_jumps(4);
        System.out.println(r);
    }
}
