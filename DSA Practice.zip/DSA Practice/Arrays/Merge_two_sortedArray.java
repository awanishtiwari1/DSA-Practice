import java.util.Arrays;

public class Merge_two_sortedArray {
    public void merge(int[] nums1 , int[] nums2, int m , int n )
    {
        int i = 0 , j = 0, k = m-1;
        while (i<k && j<n)
        {
            if(nums1[i]<nums2[j])
            {
                i++;
                continue;
            }
            else
            {
                int temp  = nums1[k];
                nums1[k] = nums2[j];
                nums2[j] = temp;
                j++;
                k--;
            }
        }
        Arrays.sort(nums1);
        Arrays.sort(nums2);
    }
    public static void main(String[] args) {
int[] a = {0,1,2,3};
int[] b = {4,5,6,7};
int m = a.length;
int n = b.length;
        Merge_two_sortedArray m1 = new Merge_two_sortedArray();
        m1.merge(a,b,m,n);
        System.out.println("After sorting");
        for(int i = 0 ; i<a.length ; i++)
        {
            System.out.println(a[i]);
        }
        for(int i = 0 ; i<b.length;i++)
        {
            System.out.println(b[i]);
        }

    }
}
