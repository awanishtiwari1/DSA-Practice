package Queues;

import java.util.Scanner;

public class queue_Implementation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        myQueue queue = new myQueue(40);
        while (true)
        {
            System.out.println();
            System.out.println("Press 1 for insert into Queue" + " " + "Press 2 for delete element \n" + "Press 3 for print elements of queue");
            System.out.println("press 4 for exit");
            int choice = sc.nextInt();
            if(choice == 1)
            {
                System.out.println("Enter data");
                int data = sc.nextInt();
                queue.enQueue(data);
            }
            if(choice == 2)
            {
                queue.deQueue();
            }
            if(choice == 3)
            {
                queue.print_Queue();
            }
            if(choice == 4)
            {
                System.exit(1);
            }

        }
    }
}
class myQueue{
   static  int front;
   static  int rear;
    static int capacity;
   static  int a[];
     static int length;
    public myQueue(int capacity)
    {
        this.capacity = capacity;
        front = 0;
        rear = 0;
        a = new int[capacity];
        length = 0;
    }
   public static void enQueue(int data)
    {
        if(length == capacity)
        {
            System.out.println("Queue is Full bhai");
        }
        else{
            length++;
            a[rear % capacity] = data;
           rear = (rear+1) % capacity;
        }
    }

   public static int deQueue()
    {
        if(length == 0)
        {
            System.out.println("Queue khali h bhai");
        }

        int data = a[front%capacity];
        a[front] = Integer.MIN_VALUE;
        front = (front+1) % capacity;
        length--;
        return data;
    }
   public static void print_Queue()
    {
        if(length == 0)
        {
            System.out.println("Nothing to show");
        }
        else
        {
            int t = front;
            while((t % capacity )!= rear)
            {
                System.out.print(a[t] + " ");
                t = (t +1) % capacity;
            }
        }

    }

}