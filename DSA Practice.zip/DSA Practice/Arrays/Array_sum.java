import java.util.Scanner;

public class Array_sum {
    public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter no of elements to store ");
            int n  = sc.nextInt();
            int a[] = new int[n];
//Taking input of array elements
            System.out.println("Enter elements in the array ");
            for(int i = 0 ; i < n ; i++)
            {
                a[i] = sc.nextInt();
            }
            int sum = 0;
            //Calculating sum of all elements of an array by iterating through all elements
            for(int i = 0 ; i < n ; i++)
            {
                sum = sum + a[i];
            }

        System.out.println("Sum of the given elements is :" + sum);

    }
}
