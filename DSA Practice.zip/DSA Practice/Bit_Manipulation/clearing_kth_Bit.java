package Bit_Manipulation;

public class clearing_kth_Bit {
    static int clear_kth_Bit(int n , int k)
    {
        //to clear the kth bit first we will create a mask for n
        //Which have a bit 1 where we have to clear
        //After that we will take a reverse of all bits to be 0 at where we have to change and one at all places
        //and after perform AND operation with n and mask

        int mask = ~(1 <<k);

        int res = n & mask;
        return res;






    }
    public static void main(String[] args) {
        int n = 5;
        int k = 2;
        System.out.println(clear_kth_Bit(n,k));
        //Here output will be 1 because after we clear 2nd bit 5 , it will remain only 1
    }
}
