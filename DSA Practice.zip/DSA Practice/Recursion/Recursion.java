public class Recursion {
    static void reverse(String s )
    {
        String res = "";
        for(int i = s.length()-1;i>0;i--)
        {
            char t = s.charAt(i);
            res = t + res;
        }

        System.out.println(res);
    }
    public static void foo(boolean a , boolean b)
    {
        if(a)
        {
            System.out.println("A");
        }
        else if(a&&b)
        {
            System.out.println("A&&B");
        }
        else
        {
            if(!b)
            {
                System.out.println("notB");
            }
            else
            {
                System.out.println("ELSE");
            }
        }
    }
//
//
//
//   }
    public static void main(String[] args) {
//        int res = 0;
//        Boolean b1 = new Boolean("TRUE");
//        Boolean b2 = new Boolean("true");
//        Boolean b3 = new Boolean("tRuE");
//        Boolean b4 = new Boolean("false");
//        if(b1 == b2)
//        {
//            res =1;
//        }
//        if(b1.equals(b2))
//        {
//            res+=10;
//        }
//       if(b2 == b4)
//       {
//           res+=100;
//       }
//       if(b2.equals(b4))
//       {
//           res+=1000;
//       }
//       if(b2.equals(b3))
//       {
//           res+=10000;
//       }
//        System.out.println(res);

        //Question 2
//
//Question 5
//        try{
//            badMethod();
//            System.out.println("A");
//        }
//        catch (RuntimeException ex)
//        {
//            System.out.println("B");
//            throw new RuntimeException();
//        }
//        catch(Exception ex1)
//        {
//            System.out.println("C");
//        }
//        finally {
//            System.out.println("D");
//        }
//        System.out.println("E");
//    }
//    public static void badMethod()
//    {
//        throw new RuntimeException();
//    }
//        try {
//            throw new exc1();
//        }
//        catch (exc e0)
//        {
//            System.out.println("ex0 caught");
//        }
//        catch (Exception e)
//        {
//            System.out.println("Exception caught");
//        }


        //Question 7
//        foo(false,true);
        reverse("Hello bhai kaise ho");
    }
}

