package Arrays;

import java.util.ArrayList;
import java.util.List;

import static java.util.Arrays.asList;

public class three_Sum_Problem {
    public  static List<List<Integer>> merge(int[] a)
    {
        List<List<Integer>> res = new ArrayList<>();
        for(int i = 0 ; i < a.length - 1 ; i++)
        {
            int j = i + 1;
            int cur = a[i] + a[j];
            int p = 0;
            while (p < a.length -1) {
                if (a[p] + cur == 0 && i != j && j != p) {
                    res.add(asList(a[i], a[j], a[p]));
                }
            }
        }



    return res;
    }

    public static void main(String[] args) {
        int a[] = {-1,0,1,2,-1,-4};
        System.out.println(merge(a));
    }
}
