public class Heap_Operations {
   static void buildHeap(int a[],int n)
   {
      //int n = a.length;
      int start  = (n/2) -1;
       for(int i=start;i>=0;i--)
       {
           heapify(a,n,i);
       }
   }
 static void heapify(int a[] , int n , int i)
{
    int largest = i;
    int l = (2*i);
    int r = (2*i)+1;
    if(a[l]>a[largest] && l<n)
    {
        largest = l;
    }
    if(a[r]>a[largest] && r<n)
    {
        largest = r;
    }
    if(largest!=i)
    {
        //Swap a[i] and a[largest]
        int temp = a[i];
        a[i] = a[largest];
        a[largest] = temp;
        heapify(a,n,largest);
        //Recursive call of the largest node and start heapifying from that largest node because all the orientation have got disturbed
    }

}



    public static void main(String[] args) {
        int a[] = {1,3,5,4,6,13,10,9,8,15,17};
        int n = a.length;
        buildHeap(a,n);
        //System.out.println("Length of the arrray is"+ a.length);
        System.out.println("Heap builded");
        for(int i =0 ; i<n;i++)
        {
            System.out.print(a[i] + " ");
        }
    }
}
