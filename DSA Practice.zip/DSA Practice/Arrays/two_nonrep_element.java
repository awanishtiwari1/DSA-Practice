public class two_nonrep_element {
    public static void main(String[] args) {

    }
}
