//The main drawback of the stack implementation using array is that we will have to tell the
//size of the array before using it
public class Stack_using_Array {
     static class myStack{
        int a[];
        int top;
        int capacity;
        public myStack(int capacity)
        {
            this.capacity = capacity;
            top = -1;
            a = new int[capacity];
        }
        void push(int data)
        {
            if(top == capacity - 1)
            {
                System.out.println("Stack overflow");
            }
            else
            {
                top++;
                a[top] = data;
            }
        }
        int pop()
        {
            if(top== -1)
            {
                System.out.println("Stack underflow");
            }

               int result = a[top];
               top--;
            return result;

        }
        int peek()
        {
            if(top==-1)
            {
                System.out.println("Stack underflow");
            }
            int res = a[top];
            return res;
        }
        boolean isEmpty()
        {
            if(top==-1)
            {
                return false;
            }
            else
                return true;
        }
        void show_Stack()
        {
            if(top==-1)
            {
                System.out.println("No any element present in the stack");
            }
            for(int i = top ; i>=0 ;i--)
            {
                System.out.print(a[i] + " ");
            }

        }


    }
    public static void main(String[] args) {
        myStack s = new myStack(10);
        s.push(1);
        s.push(2);
        s.push(3);
        s.push(4);
        s.push(5);
        s.show_Stack();
        System.out.println();
        System.out.println("Pop an element from the stack ");
        System.out.println(s.pop());
    }
}
