import java.util.Scanner;

public class Bubble_sort {


    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter no of  element");
        int a  = s.nextInt();
        int ar[] = new int[a];
        System.out.println("Enter elements in array");
        for(int i = 0 ; i < ar.length;i++)
        {
            ar[i] = s.nextInt();
        }
       for(int i = 1 ; i< ar.length ;i++)
       {
           //Here a boolean variable is used in way so that if an array is already sorted than no need to iterate more than one times
           boolean swapped = false;
           for(int j = 0 ; j< ar.length ; j++)
           {
               if(ar[i]<ar[j])
               {
                   int temp = ar[i];
                   ar[i] = ar[j];
                   ar[j] = temp;
                   swapped = true;
               }

           }
if(swapped == false)
    break;


       }
        System.out.println("Sorted element");
        for(int i = 0 ; i< ar.length ;i++) {
            System.out.println(ar[i]);

        }






    }
}
//Time complexity : O(n^2)
//Space complexity : O(1)