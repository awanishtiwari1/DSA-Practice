public class Heap_Sort {
    void sort(int a[])
    {
        int n = a.length;
        //Build heap first
        for(int i = n/2 -1 ; i>=0 ; i--)
        {
            heapify(a,n,i);
        }
        //Extract element one by one from heap
        for(int i = n-1 ; i>0; i--)
        {
            int temp = a[0];
            a[0] = a[i];
            a[i] = temp;

            heapify(a,i,0);
        }
    }
    void heapify(int a[] , int n , int i)
    {
        int largest = i ;
        int left = 2*i;
        int right = 2*i+1;//When index start from 0
        //If left child is larger than root node
        if(left < n && a[left]>a[largest])
        {
                largest = left;
        }
        if(right<n && a[right]>a[largest])
        {
            largest = right;
        }
        if(largest!=i)
        {
            int temp = a[i];
            a[i] = a[largest];
            a[largest] = temp;
            heapify(a,n,largest);
        }
    }

    public static void main(String[] args) {
        int a[] = { 20,50,38,22,10,29};
        Heap_Sort h = new Heap_Sort();
        h.sort(a);
        System.out.println("Element after sorted");
        for(int i =0 ; i< a.length ; i++)
        {
            System.out.println(a[i]);
        }
    }
}
