import java.util.Scanner;

public class binary_search {

    int binarysearch(int a[] , int key)
    {
        int low = 0 ;
        int high = a.length-1;
        while (low<high)
        {
            int mid = (low+high)/2;
            if(a[mid] == key)
            {
                return 1;
            }
            else if(key>mid)
            {
                low = mid +1 ;
            }
            else
                high = mid -1;
        }
        return -1;

    }

    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter no of elements ");
//        int n = sc.nextInt();
//        int a[] = new int[n];
//        System.out.println("Enter elements in the list");
//        for(int i =0 ; i < n ; i++)
//        {
//            a[i] = sc.nextInt();
//
//        }
        binary_search b = new binary_search();
        int a[] = {1,5,7,9,10};
        if(b.binarysearch(a,7) == 1)
        {
            System.out.println("Element found bhaiwa");
        }
        else
        {
            System.out.println("not found");
        }

    }
}
