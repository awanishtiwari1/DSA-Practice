import java.util.Scanner;

public class Sorting_Algorithms {
    static void  bubble(int a[])
    {
        for(int i = 1 ; i< a.length;i++)
        {
            for(int j = 0 ; j<a.length ; j++)
            {
                if(a[i]<a[j])
                {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
    }

    static void insertion_sort(int a[])
    {
        for(int i = 1 ; i<a.length ; i++)
        {
            int temp = a[i];
            int j = i-1;
            while (j>=0 && a[j]>temp)
            {
                a[j+1] = a[j];
                j--;
            }
            a[j+1] = temp;
        }


    }
    static void Quick_Sort(int a[] , int start , int end)
    {
        if(start<end)
        {
            int pivot = partition(a,start,end);
            Quick_Sort(a,start,pivot-1);
            Quick_Sort(a,pivot+1,end);

        }


    }
    static int partition(int a[], int start ,int end )
    {
        int pivot = a[end];
        int i = start -1;
        for(int j = start ; j<=end-1;j++)
        {
            if(a[j]<pivot)
            {
                //swap a[j] and a[i++]
                i++;
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
        i++;
        int temp = a[end];
        a[end] = a[i];
        a[i] = temp;
        return i;
    }
    static void Selection_Sort(int a[])
    {
        for(int i = 0;i<a.length;i++)
        {
            int min = i;
            for(int j = i+1;j<a.length;j++)
            {
                if(a[j]<a[min])
                {
                    min = j;
                }
            }
            if(min!=i)
            {
                int temp = a[i];
                a[i] = a[min];
                a[min] = temp;
            }
        }
    }

    public static void main(String[] args) {
    int a[] = {20,5,3,1,90,87,0};
    int n = a.length -1;
    Selection_Sort(a);
        System.out.println("Array after sort");
        for(int i = 0 ; i<a.length;i++)
        {
            System.out.print(a[i] + " ");
        }

    }
}
