package String2;

public class reverse_String {
    public static void main(String[] args) {
        String s = "hello";
//        //Method 1 :
//        String f = "";
//        char ch[] = s.toCharArray();
//        for(int i = 0 ; i< ch.length ; i++)
//        {
//            char c = s.charAt(i);
//            f = c + f ;
//        }
//        System.out.println(f);

//        method 2:
//        We will swap start and end of the chr array while(star<end)
        String s2 = "Awanish";
        char ch[] = s2.toCharArray();
        int end = ch.length-1;
       int  start = 0;
       //Here basically we are swapping the starting and end elements and increse their pointer until they are equal
        //Time complexity will be O(n)
        while(start<end)
        {
            char temp = ch[start];
            ch[start] = ch[end];
            ch[end] = temp;
            start++;
            end--;
        }
        System.out.println(ch);

        //########################################################################################




    }
}
