import java.util.ArrayList;

public class Arraylist<I extends Number> {
    public static void main(String[] args) {
        ArrayList<Integer> l1 = new ArrayList<>();
        for(int i = 1 ; i<= 10 ; i++)
        {
            l1.add(i);
        }
        //Setting the value at specified index
        //if the value of the index is already present then array is shifted
        //the element at postion 0 is 1
        //We will insert element at 0 and it will shift all element one right shift and insert at given position
        l1.add(0,20);
        //Function checks that wheather any element is present in an arrayList or not
        System.out.println("Is there is any element in the list ");
        System.out.println(l1.isEmpty());






    }
}
