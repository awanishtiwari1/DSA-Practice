package Recursion;

public class Fast_Exponentiation {
    static int fast_Expo(int n)
    {
        if(n == 0)
        {
            return 1;
        }
        int chota_answer  = fast_Expo(n/2);
        if(n%2 == 0)
        {
            return  chota_answer * chota_answer;
        }
        return 2 * chota_answer * chota_answer;

    }

    public static void main(String[] args) {
    int r = fast_Expo(5);
        System.out.println(r);
    }
}
