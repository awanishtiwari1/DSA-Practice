package Trees;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;


//Optimised level order traversal in O(n)

public class level_Order_Traversal_Optimised {
    static Node createtree()
    {
        Scanner sc = new Scanner(System.in);
        Node root = null;
        System.out.println("Enter data");
        int data = sc.nextInt();
        if(data == -1)
        {
            return null;
        }
        root = new Node(data);
        System.out.println("Enter left for " + data);
        root.left = createtree();
        System.out.println("Enter right for" + data);
        root.right = createtree();
        return root;
    }

    //This function will return the level by line
    static void level_Order_Traversal(Node root)
    {
        Queue<Node> q = new LinkedList<>();
        q.add(root);q.add(null);
        while (!q.isEmpty())
        {
            Node cur = q.poll();
            if(cur == null)
            {
                if(q.isEmpty())
                {
                    return;
                }
                q.add(null);
                System.out.println();
                continue;
            }
            System.out.print(cur.data);
            if(cur.left!=null)
            {
                q.add(cur.left);
            }
            if(cur.right!=null)
            {
                q.add(cur.right);
            }

        }



    }


    public static void main(String[] args) {
        System.out.println("Enter node os the tree");
        Node root = createtree();
        level_Order_Traversal(root);


    }
}
