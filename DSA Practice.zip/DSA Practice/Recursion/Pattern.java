public class Pattern {
    static void patter1(int n )
    {
        int space = 1;
        int p=0;
        for(int i = 1;i<=n ; i++)
        {
            for(int s=1 ; s<=space;s++)
            {
                System.out.print(" ");
            }space++;
            for(int j=1;j<=2*(n-i)-1;j++)
            {
                System.out.print("*");

            }
            System.out.println();
        }

    for(int k =1 ; k<=n ; k++)
    {
        for(int j = 1 ; j<=n*n;j++)
        {
            if(j==(space-1))
                System.out.print("@");
            else
                System.out.print(" ");

        }
        System.out.println();
    }
    for(int i = 1 ; i<=n; i++)
    {
        for(int j = 1 ;j<=n/2;j++)
        {
            System.out.print(" ");
        }
        for(int j = 1;j<=n;j++)
        {
            System.out.print("*");
        }
        System.out.println(" ");
    }



    }
    public static void main(String[] args) {
        patter1(13);
    }
}
