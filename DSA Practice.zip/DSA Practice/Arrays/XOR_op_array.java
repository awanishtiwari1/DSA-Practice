//A program to find element in array which is not repeated twice as like the other elements
//finds that no

public class XOR_op_array {
    public static void main(String[] args) {
        int a[] = {5,4,1,4,3,5,1,};
        int result = 0 ;
        for(int i = 0 ; i <a.length ; i++)
        {
          for(int j = i+1; j<a.length; j++)
          {
              result = a[i] ^ a[j];
          }

        }
        System.out.println(result);
    }
}
