import javax.swing.*;
import java.util.Arrays;

public class String_Challenge_Easy {
   String StringChallenge(String str)
    {

        int n = str.length();
        char ch[] = new char[n];
        for(int i =0;i<n;i++)
        {
            ch[i] = str.charAt(i);
        }
        int p = ch.length;
        char c[] = new char[p];
        for(int i =0;i<n;i++)
        {
            c[i] = ch[i];
        }

        //Keeping temporary value of original string for comparison
        int start = 1;
        //int end  = p-1;
        while (start <p/2)
        {
                char temp = ch[start];
                ch[start] = ch[start+1];
                ch[start+1] = temp;
                 start = start+2;
        }
        String s = "";
//        if(Arrays.equals(ch,c) != true)
//        {
//                return "-1";
//        }

        for(int i = 0 ;i<ch.length;i++)
        {
            s = s+ch[i];
        }
        return s;
    }
    public static void main(String[] args) {
        String_Challenge_Easy s = new String_Challenge_Easy();
        String a = "anna";
        String p = s.StringChallenge(a);
        System.out.println("Your result is :");
        System.out.println(p);
    }
}
