package Stacks;

import java.util.Stack;

public class next_Smaller {
    public static void next_smaller(int a[])
    {
        int b[] = new int[a.length - 1];
        int k = 0;
        Stack<Integer> s = new Stack<>();
        for(int i =a.length-1; i >0 ; i--)
        {
            while (!s.isEmpty() && s.peek() >=a[i])
            {
                s.pop();
            }
            if(s.isEmpty())
            {
                b[k] = -1;
                k++;
            }
            else {
                b[k] = s.peek();
                k++;
            }
            s.push(a[i]);
        }
        for(int i = b.length -1 ; i >= 0; i--)
        {
            System.out.print(b[i] + " ");
        }
    }

    public static void main(String[] args) {
int a[] = {3,10,5,1,15,10,7,6};
next_smaller(a);
    }
}
