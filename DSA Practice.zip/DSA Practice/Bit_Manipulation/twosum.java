class Solution {
    public static boolean twoSum(int[] numbers, int target) {

        int arr[]=new int[2];
        int i=0;
        int j=numbers.length-1;
        while(i<j){
            int sum=numbers[i]+numbers[j];
            if(sum==target){
                arr[0]=i+1;
                arr[1]=j+1;
                return true;
            }else if(sum>target){
                j--;
            }else{
                i++;
            }

        }
        return false;
    }
    static void reverse(String s )
    {
        String r[] = s.split(" ");
        String ans = "";
        for (int i = r.length - 1; i >= 0; i--) {
            ans += r[i] + " ";
        }
        System.out.println("Reversed String: " + ans);
    }
//    static int fib(int n)
//    {
//        if (n <= 1)
//            return n;
//        return fib(n-1) + fib(n-2);
//    }
static int factorial(int n)
{

    // Handling base case
    // iIf value of n=1 or n=0, it returns 1
    if (n == 0 || n == 1)
        return 1;

    // Generic case
    // Otherwise we do n*(n-1)!
    return n * factorial(n - 1);
}

    public static void main(String[] args) {
       String s = "ABC";
       s.toLowerCase();
       s = s + "def";
        System.out.println(s);
    }
}