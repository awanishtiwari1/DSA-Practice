package Recursion;

public class Check_Pallindrome_String {

    static boolean check_pallindrome(String s , int start , int end )
    {
        if(start >= end )
        {
            return true;
        }
        return (s.charAt(start) == s.charAt(end)) && check_pallindrome(s , start+1 ,end - 1);



    }
    public static void main(String[] args) {
        String s = "naman";
        int start = 0;
        int end = s.length() - 1;
        System.out.println(check_pallindrome(s,start,end));
    }
}
