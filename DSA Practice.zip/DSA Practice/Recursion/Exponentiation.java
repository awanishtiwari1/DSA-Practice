package Recursion;

public class Exponentiation {
    static int exponentiation(int n )
    {
        //Base case for n = 0 , because n to the power zero is always zero
        if(n == 0)
        {
            return 1;
        }

        int answer = 2 * exponentiation(n-1);
        return answer;
    }

    public static void main(String[] args) {
        int r = exponentiation(5);
        System.out.println(r);
    }
}
