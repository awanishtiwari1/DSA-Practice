import java.util.Arrays;

public class Sorted_Array_merge {

    //#Naive Solution ith complexity Om(nmlogn) and sc = O(n+m)
//    static void merge(int a1[], int m , int a2[],int n)
//    {
//        int b[] = new int[m+n];
//        for(int i = 0 ; i < m ; i++)
//        {
//            b[i] = a1[i];
//        }
//        for(int i = 0;i<n;i++)
//        {
//            b[m] = a2[i];
//            m++;
//        }
//        Arrays.sort(b);
//        System.out.println("Sorted Array ");
//        for(int i = 0 ; i<b.length ;i++)
//        {
//            System.out.print(b[i] + " ");
//        }
//    }


    static void sort2(int a1[],int a2[],int m , int n)
    {
        int i = 0;
        int j =0 ;
        while(i<m && j<n)
        {
            if(a1[i]>a2[j])
            {
                int temp = a1[i];
                a1[i] = a2[j];
                a2[j] = temp;
                i++;
            }
            else
                j++;

        }
        System.out.println("Array one is");
        for(int p = 0 ; p<m;p++)
        {
            System.out.print(a1[p] + " ");
        }
        System.out.println(" ");
        System.out.println("Array 2 is");
        for(int s =0 ; s< n;s++)
        {
            System.out.print(a2[s] + " ");
        }

    }
    public static void main(String[] args) {
        int a1[] = {1,2,7,8,9};
        int a2[] = {3,4,5,6};
        int l1 = a1.length;
        int l2 = a2.length;
        sort2(a1,a2,l1,l2);
    }
}
