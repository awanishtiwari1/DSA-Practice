package String2;

import java.util.Locale;

public class String_Methods {
    public static void main(String[] args) {
        //Following are some examples of string methods

        String s1 = new String("AWANISh");
//        String s2 = s1.toLowerCase();
//        System.out.println(s2);

//         String s2 = s1.replace('S','t');
//        System.out.println(s2);
//

        String s3 = new String("         Pandit            ");
        System.out.println(s3);
        //Trim function only removes spaces from begining and the end of the strig
        System.out.println("After trim");
        String s4 = s3.trim();
        String s5 = s4;
        if(s4.compareTo(s5) == 0)
        {
            System.out.println("String matched bhai");
        }


    }
}
