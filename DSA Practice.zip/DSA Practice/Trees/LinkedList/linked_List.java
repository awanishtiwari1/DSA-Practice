public class linked_List {
    Node head;

    static class Node{
        int data;
        Node next;
        Node(int data)
        {
            this.data = data;
            this.next = null;
        }
    }

    public static void traverse(linked_List list)
    {
        Node temp = list.head;
        while(temp!=null)
        {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }

    }


    public static linked_List insert(linked_List list, int data)
    {
        Node new_node = new Node(data);
        new_node.next = null;
        Node temp = list.head;
        if(list.head == null)
        {
            list.head = new_node;
        }
        else
        {
           while (temp.next!=null)
           {
               temp = temp.next;
           }
           temp.next = new_node;
        }

        return list;
    }
public static linked_List delete_from_End(linked_List list)
{
    if(list.head == null)
    {
        return null;
    }
    else
    {

        Node curr = list.head;
        Node prev = list.head;
       while (curr.next!=null)
       {
           curr = curr.next;
       }
       while(prev.next!=curr)
       {
           prev = prev.next;
       }
          prev.next = curr.next;
    }
    return list;
}
    public static void main(String[] args) {
        linked_List list = new linked_List();
        list = insert(list , 1);
        list = insert(list , 2);
        list = insert(list , 3);
        list = insert(list , 4);
        list = insert(list , 5);
        traverse(list);
        System.out.println();
        System.out.println("After deleteion of a node from end ");
       // System.out.println();
        list = delete_from_End(list);
        traverse(list);
    }


}
