package Arrays;

import java.util.Scanner;
//The problem is for rotating a matrix by 90 degree and space complexity O(n ^ 2)
public class Rotate_Matrix {
    public static void main(String[] args) {

        int a[][] =  { {1,2,3} ,
                {4,5,6},
                {7,8,9},
                {11,12,13}
                };
       int b[][] = new int[3][4];
//
//        System.out.println("Enter elements in the 3*3 matrix");
//        Scanner sc = new Scanner(System.in);
//        int k = 2;
//        for(int i = 3 ; i>=0 ; i--)
//        {
//            for(int j = 0; j<4 ; j++)
//            {
//                b[j][i] = a[j][i];
//
//            }
//        }
//        System.out.println("The resultant matrix is");
//        for(int i = 3 ; i>=0 ; i--)
//        {
//            for(int j = 0; j<4 ; j++)
//            {
//                System.out.print(b[j][i] + " ");
//
//            }
//            System.out.println();
//        }

        for(int i = 0 ; i<a.length -1 ; i++)
        {
            for(int j = 0 ; j<a[0].length -1 ; j++)
            {
                b[i][j] = a[j][i];
            }
        }
        System.out.println("Transpose of the matrix is ");
        for(int i = 0 ; i<4  ; i++)
        {
            for(int j = 0 ; j<3 ; j++)
            {
                System.out.print(b[i][j] + " ");
            }
            System.out.println();
        }

    }
}
