import java.util.Scanner;

public class Arrays {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter no of elements to store ");
        int n  = sc.nextInt();
        //Arrays can be created in two ways
        //1 way
        //int a[];
       // a[] = new int[n]
        //2 way
        int a[] = new int[n];
//Taking input of array elements
        System.out.println("Enter elements in the array ");
        for(int i = 0 ; i < n ; i++)
        {
            a[i] = sc.nextInt();
        }
        //displaying the entered value of user
        System.out.println("Elements entered by you is :");
        for(int i = 0 ; i < n ;i++)
        {
            System.out.print(a[i]);

        }

    }

    public static void sort(int[] a) {
    }
}
