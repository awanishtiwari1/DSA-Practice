import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class one_Line_Input {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        float b = 5;
        InputStreamReader in = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(in);
        //When multiple integers are to be taken at at a time in one line
        System.out.println("Enter your integer numbers");
        try {
            String input = br.readLine();
            //int n[] = new int[10];
            char s1[] = new char[10];
            for(int i =  0 ; i<input.length() ; i++)
            {
                s1[i] = input.charAt(i);
            }
//            int min = 0;
//            int max = 0;
            int min = s1[0];
            int max = s1[0];
            for(int i = 0 ; i< s1.length ; i++)
            {

                if((int)s1[i]<min)
                {
                    min  = s1[i];
                }
                if((int)s1[i]>max)
                {
                    max = s1[i];
                }
            }

            int result  = min + max;

            System.out.println(result);



        }
        catch (IOException e) {
            e.printStackTrace();
        }


    }
}
