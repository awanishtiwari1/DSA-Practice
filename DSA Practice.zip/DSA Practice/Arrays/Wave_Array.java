import java.util.Scanner;

public class Wave_Array {
    void sort_wave(int a[])
    {
        int n = a.length;
        for(int i = 0 ; i< n-1 ; i+=2)
        {
            if(a[i]<a[i+1])
            {
                int temp = a[i];
                a[i] = a[i+1];
                a[i+1] = temp;
            }
        }
    }
    public static void main(String[] args) {
       int a[] = {10,90,49,2,1,5,23};
       Wave_Array w  = new Wave_Array();
       w.sort_wave(a);
       for(int i = 0 ; i < a.length ;i++)
       {
           System.out.print(a[i] + " ");
       }
    }
}
