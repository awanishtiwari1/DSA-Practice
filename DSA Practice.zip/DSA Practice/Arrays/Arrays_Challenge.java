import java.util.Arrays;
public class Arrays_Challenge {
    int ArrayChall(int a[])
    {
        Arrays.sort(a);
        int n = a.length;
        int count = 0;
        for(int i =0 ; i< n;i++)
        {
            if(a[i]<=0)
            {
                continue;
            }
            else
            {
                count++;
            }
        }
        int sum = 0;
        if(count<4)
        {
            for(int i =0 ;i<n;i++)
            {
                sum = sum + a[i];
            }
        }
        if(count>=4)
        {
            for(int i = n-1 ; i>=n-4;i--)
            {
                sum = sum + a[i];
            }
        }
        return sum;
    }
    public static void main(String[] args) {
        int a[] = {0,0,2,3,7,1};
        Arrays_Challenge t = new Arrays_Challenge();
        int p = t.ArrayChall(a);
        System.out.println(p);
    }
}
