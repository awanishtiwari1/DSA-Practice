import java.util.Scanner;


//Program for Addition of two matrices
public class Array2d {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int row,column;
        System.out.println("Enter no of row and columns");
        row = sc.nextInt();
        column = sc.nextInt();
        //Declaring a 2d array as provided row and column
        int a[][] = new int[row][column];
        int b[][] = new int[row][column];
        int c[][] = new int[row][column];


        //Taking elements in matrix1
        //Taking elements in matrix1
        for(int i = 0 ; i<row ; i++)
        {
            for(int j = 0 ; j<column ; j++)
            {
                a[i][j] = sc.nextInt();
            }
        }
        System.out.println("Enter elements in matrix2");
        //Taking elements in matrix2
        for(int i = 0 ; i<row ; i++)
        {
            for(int j = 0 ; j<column ; j++)
            {
                b[i][j] = sc.nextInt();
            }
        }
        //Adding elements of the two matrix
        for(int i =0 ; i < row ; i++)
        {
            for(int j = 0 ; j<column ; j++)
            {
                c[i][j] = a[i][j] + b[i][j];
            }
        }

        //Displaying the addition matrix
        for(int i =0 ; i<row ; i++)
        {
            for(int j = 0 ; j<column ; j++)
            {
                System.out.println(c[i][j]);
            }
        }




    }
}
