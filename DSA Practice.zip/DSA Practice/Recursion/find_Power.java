package Recursion;
//Power of a number n to the power of k
public class find_Power {
    static int find_p(int n , int p)
    {
        if(p == 0)
        {
            return 1;
        }
        return n * find_p(n , p-1);
    }
    public static void main(String[] args) {
        System.out.println(find_p(2,5));
    }
}
