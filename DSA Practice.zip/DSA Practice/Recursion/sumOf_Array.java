package Recursion;

public class sumOf_Array {
    static int result = 0;
    static int get_Array_Sum(int a[] , int start)
    {
        if(start == a.length - 1)
        {
            return result+=a[start];
        }
        result += a[start];
        return get_Array_Sum(a, start+1);

    }
    public static void main(String[] args) {
        int a[] = { 1,2,3,4,5,6,7,8,9,10};
        System.out.println(get_Array_Sum(a , 0));
    }
}
