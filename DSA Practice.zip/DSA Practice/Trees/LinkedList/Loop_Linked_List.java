package LinkedList;


public class Loop_Linked_List {
public static linkedList.Node find_Loop(linkedList l)
{
    linkedList.Node slowptr = l.head;
    linkedList.Node fastptr = l.head;
    int count = 0;

    while(fastptr!=null && fastptr.next!=null)
    {

        fastptr = fastptr.next.next;
        slowptr = slowptr.next;
        if(slowptr == fastptr)
        {

        }
    }
    return slowptr;
}
    public static void traverse(linkedList l)
    {
        linkedList.Node temp = l.head;
        while(temp != null)
        {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
    public static void main(String[] args) {
        linkedList list1 = new linkedList();
        list1 = linkedList.insert_at_Lat(list1,1);
        list1 = linkedList.insert_at_Lat(list1,2);
        list1 = linkedList.insert_at_Lat(list1,3);
        list1 = linkedList.insert_at_Lat(list1,4);
        list1 = linkedList.insert_at_Lat(list1,5);
        linkedList.Node temp = list1.head;
        while(temp.next!=null)
        {
            temp = temp.next;
        }
        linkedList.Node loop = list1.head;
        for(int i = 1 ; i< 3 ; i++)
        {
            loop = loop.next;
        }
        temp.next = loop;
        System.out.println(find_Loop(list1));
    }
}
