package Recursion;

public class test {

    static int maxs(int n , int a , int b , int c)
    {
        if(n<0)
        {
            return -1;
        }
        if(n == 0)
        {
            return 0;
        }
        int res = Math.max(maxs(n-a,a,b,c), Math.max(maxs(n-b,a,b,c) , maxs(n-c,a,b,c)));
        if(res == -1)
        {
            return -1;
        }

        return res+1;
    }
    static boolean check_pall(String s , int start , int end)
    {
        if(start>=end)
        {
            return true;
        }
        if(s.charAt(start) == s.charAt(end))
        {
            return (check_pall(s, start+1 , end - 1));
        }

       return false;
    }
    public static void main(String[] args) {
//        String s = "naman";
//        int i = 0;
//        int j = s.length() -1;
//
//        System.out.println("The String is pallindrome " + check_pall(s,i,j));
        int n = 23;
        int a = 11;
        int b = 9;
        int c = 12;
        System.out.println("The maximum of rope cut is " + " " + maxs(n,a,b,c));





    }
}
