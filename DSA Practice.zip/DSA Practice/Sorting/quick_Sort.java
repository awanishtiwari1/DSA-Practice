package Sorting;

public class quick_Sort {

    static void quick_sort(int a[] , int low , int high)
    {
        if(low < high){
            int pivot = partition(a,low , high);
            quick_sort(a,low,pivot - 1);
            quick_sort(a,pivot+1 , high);
        }


    }
    static int partition(int a[] , int low , int high){
        int pivot = a[high];
        while (low<high)
        {
            while (a[low]<pivot) low++;
            while (a[high]>pivot)high++;
            if(low < high)
            {
                int temp = a[low];
                a[low] = a[high];
                a[high] = temp;
            }


        }
        a[low] = a[high];
        a[high] = pivot;
        return high;
    }
    public static void main(String[] args) {
        int a[] = {56,34,12,0,3,2,6};
        System.out.println("Array before sorting ");
        for(int i = 0 ; i<a.length ; i++)
        {
            System.out.print(a[i] + " ");
        }
        quick_sort(a,0,a.length - 1);
        System.out.println();
        System.out.println("Array after sorting");
        for(int i = 0 ; i<a.length ; i++)
        {
            System.out.print(a[i] + " ");
        }
    }
}
