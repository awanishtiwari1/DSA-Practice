package Arrays;

import java.util.Arrays;

public class test {

    public static void main(String[] args) {

    }
}

class Node{
    int data;
    Node next;
    public Node(int data)
    {
        this.data = data;
        this.next = null;
    }



}