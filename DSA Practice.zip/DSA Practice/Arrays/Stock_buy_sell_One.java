package Arrays;

public class Stock_buy_sell_One {
        //Bruteforce method -> Time complexity O(N square )
//    static int buy_sell(int a[])
//    {
//        int maxsum = Integer.MIN_VALUE;
//        for(int i = 0 ; i< a.length ; i++)
//        {
//            for(int j = i+1 ; j < a.length ; j++)
//            {
//                int cursum = 0;
//                cursum += a[j] - a[i];
//                if(cursum > maxsum)
//                {
//                    maxsum = cursum;
//                }
//
//
//            }
//        }
//        return maxsum;
//    }


            //optimised Approach first
            //Time complexity -> O(n);
            //Space Complexity -> O(n) (for aux array)

//    static int buy_seLL(int a[])
//    {
//        int b[] = new int[a.length];
//
//        int max = Integer.MIN_VALUE;
//        int n = b.length -1;
//        for(int i = a.length -1 ; i >= 0 ; i--)
//        {
//            int cur = a[i];
//            if(cur > max)
//            {
//                max = cur;
//            }
//            b[i] = max;
//        }
//        int maxsum = Integer.MIN_VALUE;
//        for(int i = 0 ; i< a.length ; i++)
//        {
//            int cursum = 0;
//            cursum += b[i] - a[i];
//            if(cursum > maxsum)
//            {
//                maxsum = cursum;
//            }
//        }
//
//        return maxsum;
//    }

                //Optimised approach Latest
                //T.c. -> O(n)
                //S.C. -> O(1)

    static int buy_and_sell_Fastest(int a[])
    {
        int minsofar = a[0];
        int maxsum = Integer.MIN_VALUE;
        for(int i = 0 ; i< a.length ; i++)
        {
            int cursum = 0;
             minsofar = Math.min(minsofar , a[i]);
             cursum+= a[i] - minsofar;

             if(cursum > maxsum)
             {
                 maxsum = cursum;
             }
        }
        return maxsum;
    }


    public static void main(String[] args) {
        int a[] = {3,1,4,8,7,2,5};
        //System.out.println(buy_seLL(a));
       // System.out.println(buy_sell(a));
        System.out.println(buy_and_sell_Fastest(a));
    }
}
