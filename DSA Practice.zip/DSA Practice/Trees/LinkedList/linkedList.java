package LinkedList;

import java.util.Scanner;

public class linkedList {
   Node head;
   static class Node{
       int data;
       Node next;
       Node(int d)
       {
           data = d;
           next = null;
       }
   }
   public static linkedList insert_at_Begining(linkedList l , int data)
   {
       Node new_node = new Node(data);
       new_node.next = null;
       if(l.head == null)
       {
           l.head = new_node;
       }
       else
       {
           new_node.next = l.head;
           l.head = new_node;
       }
       return l;
   }
   public static linkedList insert_at_intermediate_Pos(linkedList l , int data , int pos)
   {
       Node new_node = new Node(data);
       new_node.next = null;
       if(l.head == null)
       {
           System.out.println("Bhai pehli node hi nhi hai ");
           return l;
       }
       Node prev = l.head;
       for(int i = 1 ; i< pos-1 ; i++)
       {
           prev = prev.next;
       }
       new_node.next = prev.next;
       prev.next = new_node;

       return l;
   }
 public static linkedList insert_at_Lat(linkedList l , int data){
       Node new_node = new Node(data);
       new_node.next = null;
       if(l.head == null)
       {
           l.head = new_node;
       }
       else
       {
           Node prev = l.head;
           while(prev.next!=null)
           {
               prev = prev.next;
           }
           prev.next = new_node;
       }

       return l;
 }

   public static void traverse(linkedList l)
   {
       Node temp = l.head;
       while(temp != null)
       {
           System.out.print(temp.data + " ");
           temp = temp.next;
       }
       System.out.println();
   }
    public static void main(String[] args) {
        linkedList list = new linkedList();
        Scanner sc = new Scanner(System.in);
       while (true)
       {
           System.out.print("Press 1 for insert at begining\npress 2 for insert at intermediate pos\n Press 3 for insert at last ");
           System.out.println("Press 4 for traversal of LL " + " Press 5 for exit");
           System.out.println();
           int t = sc.nextInt();
           if(t == 1)
           {
               System.out.println("Enter data");
               int data = sc.nextInt();
               list = insert_at_Begining(list , data);
           }
           if(t == 2)
           {
               System.out.println("Enter data");
               int data = sc.nextInt();
               System.out.println("Enter position where to be inserted");
               int pos = sc.nextInt();
               list = insert_at_intermediate_Pos(list ,data , pos);
           }
           if(t == 3)
           {
               System.out.println("Enter data");
               int data = sc.nextInt();
               list = insert_at_Lat(list , data);
           }
           if(t ==  4)
           {
               traverse(list);
           }
           if(t == 5)
           {
               System.exit(0);
           }
       }


    }
}
