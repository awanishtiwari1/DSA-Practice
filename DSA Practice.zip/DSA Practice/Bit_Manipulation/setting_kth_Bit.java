package Bit_Manipulation;

public class setting_kth_Bit {
    static int set_kth_bit(int n, int k)
    {
        //Creating a mask for number n
        // Here we will perform BITWISE OR Operation to set bit of either bit
        int mask  = 1 << k;
        n = n | mask;
        return n;
    }
    public static void main(String[] args) {
        int n = 5;
        int k = 2;
        System.out.println(set_kth_bit(n,k));
    }
}
