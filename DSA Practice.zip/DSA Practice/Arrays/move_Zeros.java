package Arrays;

public class move_Zeros {

   static void move(int a[])
   {
       int b[] = new int[a.length];
       int k = 0;
       int count = 0;
       for(int i = 0 ; i < a.length ; i++)
       {
           if(a[i]!=0)
           {
               b[k] = a[i];
               k++;
           }
           else
           {
               count++;
           }
       }
       for(int i = 1 ; i<= count ; i++)
       {
           b[k++] = 0;
       }
       System.out.println("Arry after movin zeros ");
        for(int i = 0 ; i<b.length ; i++)
        {
            System.out.print(b[i] + " ");
        }

   }


    public static void main(String[] args) {
        int a[] = { 0 , 1 , 0 , 1 , 3 , 5 , 0 , 6};
        move(a);
    }
}
