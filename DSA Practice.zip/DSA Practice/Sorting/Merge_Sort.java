public class Merge_Sort {
   void mergesort(int a[] , int l , int r)
   {
        if(l<r)
        {
            int mid  = (l+r)/2;
            mergesort(a,l,mid);
            mergesort(a,mid+1,r);
            //After recursive calls merge the arrays
            merge(a,l,mid,r);

        }
   }
   void merge(int a[] , int l ,int mid , int r)
   {
       int b[] = new int[r-l+1];
       int i = l;
       int j = mid+1;
       int k = 0;
       while (i<=mid && j<=r)
       {
           if(a[i]<=a[j])
           {
            b[k] = a[i];
            i++;k++;
           }
           else
           {
               b[k] = a[j];
               j++;k++;
           }

       }
       //Suppose when second array has exhausted and first array have some left elements left
       while (i<=mid)
       {
           b[k] = a[i];
           i++;k++;
       }
       //Suppose when first array has exhausted and second array have some left elements left
       while (j<=r)
       {
           b[k] = a[j];
           j++;k++;
       }
       //After merging copy all elements of temporary array to original array
    for(int p = l ; p<=r ;p++)
    {
        a[p] = b[p-l];
    }
   }

void show(int a[])
{
    for(int i = 0 ; i<a.length ;i++)
    {
        System.out.print(a[i] + " ");
    }
}


    public static void main(String[] args) {
int a[] = {4,5,0,7,6,9,1,-45,3};
int r = a.length -1;
Merge_Sort m = new Merge_Sort();
        System.out.println("Array before sorting");
        m.show(a);
        System.out.println();
        System.out.println("Array after sorting");
        m.mergesort(a,0,r);
       m.show(a);

    }
}
