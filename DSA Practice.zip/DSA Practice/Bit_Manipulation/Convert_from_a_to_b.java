package Bit_Manipulation;

public class Convert_from_a_to_b {
    //This method returns the number of bits to be changed
    //to convert number a to number b
    static int convert(int a , int b)
    {

        //By performing XOR operation we will get to know the different bits og both numbers
        int res = a ^ b;
        //In res variable we have get to know that where we have to change
        //But how to find number of 1's in res digit

        int count = 0;
        while(res!=0)
        {
            count++;
            res = res & (res -1);
        }
        return count;

    }
    public static void main(String[] args) {
        int a = 5;
        int b = 7;
        System.out.println(convert(a,b));
    }
}
