import java.util.*;

public class Binary_Search_Tree {
    static Node Createtree()
    {
        Node root = null;
        Scanner sc  = new Scanner(System.in);
        System.out.println("Enter the data");
        int data = sc.nextInt();
        if(data == -1) return null;
         root  = new Node(data);
        System.out.println("Enter left of:" + data);
        root.left = Createtree();
        System.out.println("Enter right of:" + data);
        root.right = Createtree();
        return root;
    }
    static void Inorder(Node root)
    {
        if(root == null) return ;
        Inorder(root.left);
        System.out.print(root.data + " ");
        Inorder(root.right);
    }
    public static void main(String[] args) {
        Node root  = Createtree();
        Inorder(root);
    }
}
class Node{
    Node left,right;
    int data;
    public Node(int data)
    {
        this.data = data;
    }
}