package Sorting;

public class selection_Sort {
// Selectio sort considers first index elemnt as minimum and iterate through whole array
    //if any other element less than min found it just update the min variable
    static void selection(int a[])
    {
        for(int i = 0 ; i< a.length ; i++)
        {
            int min = i;
            for(int j = i+1 ; j<a.length ; j++)
            {
                if(a[j] < a[min])
                {
                    min = j;
                }
            }
            if(min!=i)
            {
                int temp = a[min];
                a[min] = a[i];
                a[i] = temp;
            }

        }
    }
    public static void main(String[] args) {
        int a[] = {56,34,12,0,3,2,6};
        System.out.println("Array before sorting ");
        for(int i = 0 ; i<a.length ; i++)
        {
            System.out.print(a[i] + " ");
        }
        selection(a);
        System.out.println();
        System.out.println("Array after sorting");
        for(int i = 0 ; i<a.length ; i++)
        {
            System.out.print(a[i] + " ");
        }
    }
}
