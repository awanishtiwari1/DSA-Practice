public class Cycle_in_Linkedlist {
    Node head;
    static class Node{
        int data;
        Node next;
        Node(int data)
        {
            this.data = data;
            next = null;
        }
    }
    static void show_list(Node head)
    {
        Node curr = head;
        while (curr!=null)
        {
            System.out.print(curr.data + " ");
            curr = curr.next;
        }
    }
    //function which return the pointer where slow and fast meet
    //It also confirms that it contains cycle
    public static Node detect_cycle(Node head)
    {
        Node slow = head;
        Node fast = head;
        while (fast!=null && fast.next!=null)
        {
            slow = slow.next;
            fast = fast.next.next;
            if(slow == fast)
                return slow;
        }
        return null;
    }
    //Function to show that from where the cycle is started
    public static Node detect_first_node(Node head)
    {
        Node meet = detect_cycle(head);
        Node start = head;
        while(start!=meet)
        {
            start = start.next;
            meet = meet.next;
        }
        return start;
    }

    public static void main(String[] args) {
        Cycle_in_Linkedlist list = new Cycle_in_Linkedlist();
        Node head = new Node(1);
        Node second = new Node(2);
        Node third = new Node(3);
        Node fourth = new Node(4);
        Node fifth = new Node(5);
        head.next = second;
        second.next = third;
        third.next = fourth;
        fourth.next = fifth;
        //fifth.next = null;
        //It will form a cycle
        fifth.next = third;
        Node rep = detect_first_node(head);
        System.out.println("The node here  shows that from where the cycle is being started in Linked list");
        System.out.println(rep.data);
    }
}
