import java.util.Arrays;
import java.util.Scanner;
//Given an integer array A, find if an integer p exists in the array such that the number
// of integers greater than p in the array equals to p.
public class Noble_Integer_Array {
   static int noble(int a[])
    {
        Arrays.sort(a);
        int n = a.length;
        if(a[n-1] == 0) return 1;
        for(int i = 0 ; i<n-1 ;i++)
        {
            if(a[i] == a[i+1]) continue;//if eny duplicte element exists then skip that
            //A[i] >0 is here for checking negative elements
            if(a[i]>0 && a[i] == n-i-1)
            {
                return 1;
            }
        }
        return -1;



    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter size of the array ");
        int n  = sc.nextInt();
        int a[] = new int[n];
        System.out.println("Enter elements in the array ");
        for(int i =  0 ; i<a.length ;i++)
        {
            a[i] = sc.nextInt();
        }
        int p = noble(a);
        System.out.println(p);

    }
}
