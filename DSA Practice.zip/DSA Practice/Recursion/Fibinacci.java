package Recursion;

public class Fibinacci {

    static int find_fibonacci(int n)
    {
        if(n >= 2)
        {
            return (find_fibonacci(n-1) + find_fibonacci(n-2));
        }
        return 0;

    }

    public static void main(String[] args) {
        int n = 10;
        for(int i = 2 ; i<= n ; i++)
        {
            int p = find_fibonacci(i);
            System.out.println(i);
        }
    }
}
